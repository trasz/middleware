#+
# Copyright 2015 iXsystems, Inc.
# All rights reserved
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted providing that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
#####################################################################

from namespace import Namespace, Command
from builtins import functions, controls, is_pair


def sort_args(args):
    positional = []
    kwargs = {}
    opargs = []

    for i in args:
        if type(i) is tuple:
            if i[1] == '=':
                kwargs[i[0]] = i[2]
            else:
                opargs.append(i)
            continue

        positional.append(i)

    return positional, kwargs, opargs


class Symbol(object):
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return "<Symbol '{0}'>".format(self.name)

    def __repr__(self):
        return str(self)


class BinaryExpr(object):
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

    def __str__(self):
        return "<BinaryExpr left '{0}' op '{1}' right '{2}>".format(self.left, self.op, self.right)

    def __repr__(self):
        return str(self)


class SchemeExpr(list):
    def __str__(self):
        return "<SchemeExpr '{0}'>".format(super(SchemeExpr, self).__str__())


class Literal(object):
    def __init__(self, value, type):
        self.value = value
        self.type = type

    def __str__(self):
        return "<Literal '{0}' type '{1}>".format(self.value, self.type)

    def __repr__(self):
        return str(self)


class Function(object):
    def __init__(self, context, parms, exp, env):
        self.context = context
        self.parms = parms
        self.exp = exp
        self.env = env

    def __call__(self, *args):
        return eval(self.exp, Environment(self.parms, args, self.env))


class BuiltinFunction(object):
    def __init__(self, context, name, f):
        self.context = context
        self.name = name
        self.f = f

    def __call__(self, *args):
        return self.f(*args)


class ControlFunction(object):
    def __init__(self, context, name, f):
        self.context = context
        self.name = name
        self.f = f

    def __call__(self, exprs, env):
        return self.f(self.context, exprs, env)


class Environment(dict):
    def __init__(self, context, outer=None, iterable=None):
        super(Environment, self).__init__()
        self.context = context
        self.outer = outer

    def find(self, var):
        if var in self:
            return self[var]

        if self.outer:
            return self.outer.find(var)

        if var in self.context.controls:
            return ControlFunction(self.context, var, self.context.controls.get(var))

        if var in self.context.builtins:
            return BuiltinFunction(self.context, var, self.context.builtins.get(var))


class ExecutionContext(object):
    def __init__(self, context):
        self.context = context
        self.global_env = Environment(self)
        self.builtins = functions
        self.controls = controls
        self.macros = []

    def find_in_scope(self, token):
        if token in self.context.builtin_commands.keys():
            return self.context.builtin_commands[token]

        for ns in self.context.cwd.namespaces():
            if token == ns.get_name():
                return ns

        for name, cmd in self.context.cwd.commands().items():
            if token == name:
                return cmd

        return None

    def execute_cli(self, *tokens):
        tokens = list(tokens)

        while tokens:
            t = tokens.pop(0)
            print t

            if isinstance(t, Namespace):
                #self.context.cd(t)
                continue

            if isinstance(t, Command):
                t.run(self.context, *sort_args(tokens))
                return

    def eval(self, expr, env=None):
        env = env or self.global_env
        print 'expr: {0}'.format(expr)
        expr = self.expand(expr)

        print 'expr2: {0}'.format(expr)

        if isinstance(expr, Symbol):
            item = env.find(expr.name)
            if not item:
                item = self.find_in_scope(expr.name)

            if isinstance(item, Namespace):
                self.context.cd(item)

            return item

        if isinstance(expr, Literal):
            return expr.value

        if isinstance(expr, BinaryExpr):
            x = self.eval(expr.right, env)
            return expr.left, expr.op, x

        if isinstance(expr, list):
            func = self.eval(expr.pop(0), env)

            if isinstance(func, ControlFunction):
                return self.eval(func([func] + expr, env), env)

            exprs = map(lambda x: self.eval(x, env), expr)

            if isinstance(func, (Function, BuiltinFunction)):
                return func(*exprs)

            if isinstance(func, (Namespace, Command)):
                self.execute_cli(func, *exprs)
                return None

            raise SyntaxError()

    def require(self, x, predicate, message="Wrong length"):
        if not predicate:
            raise SyntaxError()

    def expand(self, x, toplevel=False):
        "Walk tree of x, making optimizations/fixes, and signaling SyntaxError."
        self.require(x, x != [])                    # () => Error

        if not isinstance(x, list):                 # constant => unchanged
            return x

        if isinstance(x[0], Symbol):
            if x[0].name == 'quote': # (quote exp)
                self.require(x, len(x) == 2)
                return x

            elif x[0].name == 'if':
                if len(x) == 3:
                    x = x + [None]     # (if t c) => (if t c None)

                self.require(x, len(x) == 4)
                return map(self.expand, x)

            elif x[0].name == 'set!':
                self.require(x, len(x) == 3)
                var = x[1]                       # (set! non-var exp) => Error
                self.require(x, type(var) is Symbol, "can set! only a symbol")
                return [Symbol('set!'), var, self.expand(x[2])]

            elif x[0].name in ('define', 'define-macro'):
                self.require(x, len(x)>=3)
                _def, v, body = x[0], x[1], x[2:]
                if isinstance(v, list) and v:           # (define (f args) body)
                    f, args = v[0], v[1:]        #  => (define f (lambda (args) body))
                    return self.expand([Symbol('define'), f, [Symbol('lambda'), args]+body])
                else:
                    self.require(x, len(x)==3)        # (define non-var/list exp) => Error
                    self.require(x, isinstance(v, Symbol), "can define only a symbol")
                    exp = self.expand(x[2])
                    if _def.name == 'define-macro':
                        self.require(x, toplevel, "define-macro only allowed at top level")
                        proc = eval(exp)
                        self.require(x, callable(proc), "macro must be a procedure")
                        self.macros[v] = proc    # (define-macro v proc)
                        return None              #  => None; add v:proc to macro_table
                    return [Symbol('define'), v, exp]

            elif x[0].name == 'begin':
                if len(x)==1: return None        # (begin) => None
                else: return [self.expand(xi, toplevel) for xi in x]

            elif x[0].name == 'lambda':   # (lambda (x) e1 e2)
                self.require(x, len(x)>=3)            #  => (lambda (x) (begin e1 e2))
                vars, body = x[1], x[2:]
                self.require(x, (isinstance(vars, list) and all(isinstance(v, Symbol) for v in vars))
                        or isinstance(vars, Symbol), "illegal lambda argument list")
                exp = body[0] if len(body) == 1 else [Symbol('begin')] + body
                return [Symbol('lambda'), vars, self.expand(exp)]

            elif x[0].name == 'quasiquote':           # `x => expand_quasiquote(x)
                self.require(x, len(x) == 2)
                return self.expand_quasiquote(x[1])

            else:
                return x

        elif type(x[0]) is Symbol and x[0] in self.macros:
            return self.expand(self.macros[x[0]](*x[1:]), toplevel) # (m arg...)

        else:                                #        => macroexpand if m isa macro
            return map(self.expand, x)            # (f arg...) => expand each

    def expand_quasiquote(self, x):
        """Expand `x => 'x; `,x => x; `(,@x y) => (append x y) """
        if not is_pair(x):
            return [Symbol('quote'), x]

        self.require(x, x[0].name != 'unquote-splicing', "can't splice here")

        if x[0].name == 'unquote':
            self.require(x, len(x) == 2)
            return x[1]
        elif is_pair(x[0]) and x[0][0] is _unquotesplicing:
            self.require(x[0], len(x[0])==2)
            return [_append, x[0][1], expand_quasiquote(x[1:])]
        else:
            return [_cons, expand_quasiquote(x[0]), expand_quasiquote(x[1:])]
