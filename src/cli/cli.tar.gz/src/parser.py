#+
# Copyright 2015 iXsystems, Inc.
# All rights reserved
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted providing that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
#####################################################################


import ply.lex as lex
import ply.yacc as yacc
from scheme import Symbol, Literal, BinaryExpr, SchemeExpr


tokens = [
    'LPAREN', 'RPAREN', 'NEWLINE', 'ATOM', 'NUMBER', 'STRING', 'ASSIGN', 'AT',
    'EQ', 'NE', 'GT', 'GE', 'LT', 'LE', 'REGEX', 'UP', 'TRUE', 'FALSE'
]


t_ignore = ' \t'
t_NEWLINE = r'\n'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_ASSIGN = r'='
t_AT = r'@'
t_EQ = r'=='
t_NE = r'\!='
t_GT = r'>'
t_GE = r'>='
t_LT = r'<'
t_LE = r'<'
t_REGEX = r'~'
t_UP = r'\.\.'
t_ATOM = r'[a-zA-Z_+-/\*]+'
t_TRUE = r'\#t'
t_FALSE = r'\#f'


def t_STRING(t):
    r'\"([^\\\n]|(\\.))*?\"'
    t.value = t.value[1:-1]
    return t


def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t


def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)


def p_stmt_list(p):
    """
    stmt_list : stmt
    stmt_list : stmt stmt_list
    """
    if len(p) == 2:
        p[0] = [p[1]]
        return

    p[0] = [p[1]] + p[2]


def p_stmt(p):
    """
    stmt : UP NEWLINE
    stmt : expr_list NEWLINE
    """
    p[0] = p[1]


def p_list(p):
    """
    list : LPAREN RPAREN
    list : LPAREN scheme_expr_list RPAREN
    """
    if len(p) == 3:
        p[0] = SchemeExpr([])
    else:
        p[0] = SchemeExpr(p[2])


def p_expr_list(p):
    """
    expr_list : expr
    expr_list : expr expr_list
    """
    if len(p) == 2:
        p[0] = [p[1]]
        return

    p[0] = [p[1]] + p[2]


def p_scheme_expr_list(p):
    """
    scheme_expr_list : scheme_expr
    scheme_expr_list : scheme_expr scheme_expr_list
    scheme_expr_list : scheme_expr NEWLINE scheme_expr_list
    """
    if len(p) == 2:
        p[0] = [p[1]]
        return

    if len(p) == 4:
        p[0] = [p[1]] + p[3]
        return

    p[0] = [p[1]] + p[2]


def p_scheme_expr(p):
    """
    scheme_expr : symbol
    scheme_expr : list
    scheme_expr : literal
    scheme_expr : binary
    """
    p[0] = p[1]


def p_expr(p):
    """
    expr : symbol
    expr : binary
    expr : list
    expr : literal
    """
    p[0] = p[1]


def p_literal(p):
    """
    literal : NUMBER
    literal : STRING
    """
    p[0] = Literal(p[1], type(p[1]))


def p_binary(p):
    """
    binary : ATOM ASSIGN expr
    binary : ATOM EQ expr
    binary : ATOM NE expr
    binary : ATOM GT expr
    binary : ATOM GE expr
    binary : ATOM LT expr
    binary : ATOM LE expr
    binary : ATOM REGEX expr
    """
    p[0] = BinaryExpr(p[1], p[2], p[3])


def p_symbol(p):
    """
    symbol : ATOM
    """
    p[0] = Symbol(p[1])


def p_error(p):
    print "error: {0}".format(p)


lex.lex()
yacc.yacc()


def parse(input):
    x = yacc.parse(input)
    print 'parse: {0}'.format(x)
    return x
